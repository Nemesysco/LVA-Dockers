#!/bin/python3
import hashlib
import json
import socket
import sys
import time
import io
import os
import random
import string
import urllib.request
import urllib.parse
import shutil
import os.path

app="LVA7"; # app="LVA7"
if app=="QA7":
	urlBase = "http://127.0.0.1/QA7/"
	recordLocalDir="/opt/lampp/htdocs/QA7/records/"
	SAMPLES=160
	realTimePort=8103
else:
	urlBase = "http://127.0.0.1/LVA7/"
	recordLocalDir="/opt/lampp/htdocs/LVA7/records/"
	SAMPLES=220
	realTimePort=12001
dockerKey='1a2b3c'
recordDockerDir="/records/"
realTimeIP="127.0.0.1"

OK=0
ERROR_FILE_OPEN=1
ERROR_SOCKET_READ=2
ERROR_SOCKET_ID=3
ERROR_SOCKET_READ=4
ERROR_SOCKET_WRITE=5
ERROR_SOCKET_CREATE=6
ERROR_GET_HOST_BY_NAME=7
ERROR_SOCKET_CONNECT=8
ERROR_FILE_COPY=9
ERROR_PCM_FILE_OPEN=10

error_codes_to_msg = {
	0 : 'OK', 
	1 : 'Error: File Open (Python)',
	2 : 'Error: Socket read (Python)', 
	3 : 'Error: Invalid Socket (Python)',
	4 : 'Error: Socket Read (Python)',
	5 : 'Error: Socket Write (Python)',
	6 : 'Error: Socket Create (Python)',
	7 : 'Error: Get Host By Name (Python)',
	8 : 'Error: Socket Connect (Python)',
	9 : 'Error: File Copy (Python)',
	10 : 'Error: PCM File Open (Python)'
}

###
# Function: qa7Answer
# Action: send a request to url (need to be _api.php?request...) and return the QA7/LVA7 Docker answer
# Input: url
# Return: the QA7/LVA7 Docker answer
###
def qa7Answer(url):
	fp = urllib.request.urlopen(url)
	mybytes = fp.read()
	mystr = mybytes.decode( "utf8" )
	fp.close()
	return mystr

###
# Function: optionURL
# Action: read the option and return an url encrypted string for these options
# Input: options: dictionary tha contains the options and their values
# Return: url encrypted string for the desired options
###
def optionURL(options):
	rc=""
	sep="&"
	
	for key in options.keys():
		if type(options[key]) is str:
			value=urllib.parse.quote(options[key])
		else:
			value=str(options[key])
		rc=rc+sep+key+"="+value
	return rc

###
# Function: findLen
# Action: return the size of a string, including binary
# Input: s : string
# Return: string size
###
def findLen(s):
	rc=0
	for i in s:
		rc+=1
	return rc

###
# Function: option2str
# Action: transcript the list of options into a string, ready for realtime
# Input: options : dictionary
# Return: string
###
def option2str(options):
	s=""
	for name in options:
		if (s!=""):
			s=s+":"
		if (type(options[name])==int):
			s=s+name+"="+str(options[name])
		else:
			s=s+name+"="+options[name]
	return (s)

###
# Function: sockRecv
# Action: Receive a string of data from the server
# Input: MySocket : socket
# Return: string
###
def sockRecv(MySocket):
	if MySocket.fileno()==-1:
		return ERROR_SOCKET_ID, error_codes_to_msg[ERROR_SOCKET_ID]
	try:
		recv=MySocket.recv(5)
		sn=recv.decode("utf-8")
		n=int(sn)
		s=""
		ns=0
		recv=MySocket.recv(1)
		while (ns<n):
			recv=MySocket.recv(n-ns)
			ns=ns+findLen(recv)
			s=s+recv.decode("utf-8")
		return OK, s
	except Exception as e:
		return ERROR_SOCKET_READ, error_codes_to_msg[ERROR_SOCKET_READ]+" ["+str(e)+"]"
		
###
# Function: sockSend
# Action: Receive a string of data from the server
# Input: 
#		MySocket : socket
#		prefix : string, determine how 
#		data: 
###
def sockSend(MySocket, prefix, data):
	if MySocket.fileno()==-1:
		return ERROR_SOCKET_ID
	try:
		n=findLen(data)
		sn="%05d" % (n)
		bn=str.encode(sn)
		asc=bn+b":"+prefix+data
		MySocket.send(asc)
		return OK
	except:
		return ERROR_SOCKET_WRITE
	
###
# Function: sockInit
# Action: Initialize the connection with the realtime server
# Input: 
#		MySocket : string - hostName of server
#		prefix : int - port of the server
#		sOption: string - string of the options (as received by option2str)
# Return: string
###
def sockInit(hostName, port, sOptions, timeout=30):
	s=0
	try:
		s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		if (timeout>0):
			s.settimeout(timeout)
	except socket.error:
		return (ERROR_SOCKET_CREATE, error_codes_to_msg[ERROR_SOCKET_CREATE], None)
		
	try:
		ip = socket.gethostbyname(hostName)
	except socket.gaierror:
		return (ERROR_GET_HOST_BY_NAME, error_codes_to_msg[ERROR_GET_HOST_BY_NAME], None);
	
	
	try:
		s.connect((ip, port))
	except:
		return (ERROR_SOCKET_CONNECT, error_codes_to_msg[ERROR_SOCKET_CONNECT], None)

	sockSend(s, b'Setting:', sOptions.encode(encoding="ascii"))

	rc, recv=sockRecv(s)
	return (rc, recv, s)

###
# Function: strRND
# Action: Return a random string
# Input: integer - size of the string
# Output: string of random character
###
def strRND(size):
	letters=string.ascii_lowercase
	rc= ''.join(random.choice(letters) for i in range(size))
	return rc

###
# Function: closeAll
# Input: array of file handles
###
def closeAll(fps):
	for fp in fps:
		if isinstance(fp, io.IOBase):
			if (fp==sys.stdout or fp==sys.stderr):
				continue
			if not fp.closed:
				fp.close()
			continue
		fn=fp.fileno()
		if fn!=-1:
			fp.close()
		
#------------------------------------------------------------------

###
# Function: audio2pcm
# Action: convert an audio file to a pcm file ready for online analysis
# Input:
#	wavFilename: wav filename
#	pcmFilename: pcm filename
# Return: #number, Error text
#		if negative, error
#		if 0, OK
###
def wav2pcm(wavFilename, pcmFilename):
	try:
		fin=open(wavFilename, "rb");
	except:
		print ("no file: "+wavFilename)
		return -1, 'Wav File open error'
	
	
	content=fin.read(2048);
	dataPos=content.find(b'data')
	if (dataPos==-1):
		fin.close()
		return -2, 'Invalid file type'
		
	dataPos+=8; # 'data' + 4 bytes for wav data length
	fin.seek(dataPos, 0);
	
	try:
		fout=open(pcmFilename, "wb");
	except:
		return -3, 'Write File open error'
	
	rc=fin.read(8192)
	while (rc):
		fout.write(rc)
		rc=fin.read(8192)
	fin.close()
	fout.close()
	
	return 0, "OK";


###
# Function: qa7Status
# Action: get the status of the LVA7/QA7 server
# Input: options (as a dictionary)
# Return: the LVA/QA7 status
###
def qa7Status(options={}):
	rc=optionURL(options)
	url=urlBase + "_api.php?action=STATUS"+rc
	return qa7Answer(url)

###
# Function: qa7Version
# Action: return the version of the LVA7/QA7 server
# Input options (as dictionary)
# Return: the QA7/LVA7 server version
###
def qa7Version(options={}):
	rc=optionURL(options)
	url=urlBase + "_api.php?action=VERSION"+rc
	return qa7Answer(url)

###
# Function: qa7Formats
# Action: get the list of codecs and audio formats support by ffmpeg (needed for the offline analysis)
# Input options (as dictionary)
# Return: the list of codecs and audio formats
###
def qa7FormatsList(options={}):
	rc=optionURL(options)
	url=urlBase + "_api.php?action=FORMATS"+rc
	return qa7Answer(url)

###
# Function: qa7License
# Action: insert a new license
# Input: 
#	license: the license added to the LVA7/QA7 Docker instance
#	key: security key string
#	options: options (as dictionary)
# Return: LVA/QA7 answer to request to add the license
###
def qa7License(license, key, options={}):
	eLicense=urllib.parse.quote(license)
	eKey=urllib.parse.quote(key)
	rc=optionURL(options)
	url=urlBase+"_api.php?action=LICENSE&license="+eLicense+"&key="+eKey+rc
	return qa7Answer(url)

###
# Function: qa7Analyze
# Action: send a file to be analyzed (offline analysis)
# Input:
#	fileURL: url to the audio file, or path to the audio file as seen from within the docker instance
#	options: options (as dictionary), with the fields
#		filename : analyzed file name (default: "")
#		analysisType: analyze type (default: 3, must be between 1 or 5)
#		Question: free text (default: "", not used in QA7)
#		Topic: free text (default: "", not used in QA7)
#		toMono: convert to mono (1 yes / 0 no - default: 0)
#		segMaxLen: maximum length of a segment in second (between 1 and 3, default: 2)
#		BG: (default 1000)
# Return: the offline analysis
###
def qa7Analyze(audioFile, options={}):
	path, filename=os.path.split(audioFile)
	dest=recordLocalDir+"/"+filename
	try:
		shutil.copy(audioFile, dest)
	except:
		return "{ 'error': '"+error_codes_to_msg[ERROR_FILE_COPY]+ "' }"
	eFileURL=urllib.parse.quote(recordDockerDir+filename);
	rc=optionURL(options)
	url=urlBase+"_api.php?action=ANALYZE&url="+eFileURL+rc
	rc=qa7Answer(url)
	os.unlink(dest)
	return rc
	
	
############### To be modified for your needs ######################
###
# Function: realtimeAnalysis
# Action: analyze a file through realtime
# Input:
#	fileOuput: file handle to write in the results or sys.stdout or sys.stderr
#	filePCM: string - Input file name (as PCM 8000Hz)
#	options: directory - analysis options. The parameters can be:
#		iBG: integer - BG (default 1000)
#		iChannels: integer - number of channels (default 1; 1 - mono, 2 - stereo)
#		iSegMaxLen: integer - maximum segement size in seconds (default 2; can be 1, 2 or 3)
#		iBitsPerSample: integer (default 16, can be 8 or 16)
#		iNoiseFilter: integer - noise filter (default 1, can be 0/none, 1/normal, 2/aggressive)
#		iStressWarnLevel: integer (default 6, between 0 to 30)
#		iConstHighEnergy: integer (default 6, between 0 to 30)
#		iCalibrationType: integer (default 3, can be 1, 2, 3, 4 or 5)
#		iChannelPriority: integer - which channel as priority in stereo (default 2 - 0 left, 1, right, 2 mixed)
#		sQuestion: string - Question for LVA7 (default "")
#		sTopic: string - Question for LVA7 (default "")
#		iGetRisk: show risk information results (default iGetRisk=0)
#  		iGetEDP: show EDP results (default iGetEDP=0)
###
def realtimeAnalysis(fileOutput, filePCM, options={}, timeout=30):
	if ('iChannels' in options):
		iChannels=options['iChannels']
	else:
		iChannels=1
	if ('iBitsPerSample' in options):
		iBitsPerSample=options['iBitsPerSample']
	else:
		iBitsPerSample=16

	fileOut=0
	if (fileOutput==sys.stdout or fileOutput==sys.stderr):
		fpOut=fileOutput
	else:
		try:
			fpOut=open(fileOutput, "w")
		except:
			fpOut=sys.stderr
			fpOut.write(error_codes_to_msg[ERROR_FILE_OPEN]+"\n")
			return ERROR_FILE_OPEN
	
	fpIn=open(filePCM, "rb")
	if (fpIn.closed):
		fpOut.write(error_codes_to_msg[ERROR_PCM_FILE_OPEN]+"\n")
		closeAll([fpOut])
		return ERROR_PCM_FILE_OPEN

	sampleSize=int(SAMPLES*iChannels*iBitsPerSample/8)
	sOption=option2str(options)


	rc, sRC,sock=sockInit(realTimeIP, realTimePort, sOption)
	if (rc!=0):
		fpOut.write(sRC+"\n")
		closeAll([fpIn, fpOut])
		return rc
	
	fpOut.write(sRC);
	rc=fpIn.read(sampleSize)

	while rc:
		rc=sockSend(sock, b"Data:", rc)
		if (rc!=0):
			fpOut.write("\n"+error_codes_to_msg[ERROR_SOCKET_WRITE]+"\n")
			closeAll([fpIn, fpOut, sock])
			return ERROR_SOCKET_WRITE;
		rc, sRC=sockRecv(sock)
		if rc!=0:
			fpOut.write("\n"+sRC+"\n")
			fpIn.close()
			closeAll([fpIn, fpOut, sock])
			return rc
		if (sRC!="CONT"):
			fpOut.write(sRC)
		rc=fpIn.read(sampleSize)
	rc=sockSend(sock, b"Done:", b'')
	if (rc!=0):
		fpOut.write("\n"+error_codes_to_msg[ERROR_SOCKET_WRITE]+"\n")
		closeAll([fpIn, fpOut, sock])
		return ERROR_SOCKET_WRITE;
	rc,sRC=sockRecv(sock)
	fpOut.write("\n"+sRC)
	closeAll([sys.stdout, sys.stderr, fpIn, fpOut, sock ])
	return OK

############### Examples #################
print ("\n\nVERSION:")
print (qa7Version({"userID": 12}))

print ("\n\nSUPPORTED FORMATS:")
print (qa7FormatsList())
	
print ("\n\nSTATUS:")
print (qa7Status())

#print ("\n\nUpdate license:")
#print (qa7License("PUT_THE_LICENSE_HERE", dockerKey , {"userID": 12}))

if os.path.isfile("5.wav"):
	print ("\n\nOFFLINE ANALYSIS:")
	print (qa7Analyze("5.wav", {}))

showedRT=False;
if os.path.isfile("1.wav"):
	if showedRT==False:
		showedRT=True
		print("\n\nREALTIME ANALYSIS:")
	print ("\nAnalyze 1.wav")
	wav2pcm("1.wav", "1.pcm")
	realtimeAnalysis(sys.stdout, "1.pcm", {'iChannels': 1, 'iSegMaxLen':2, 'iNoiseFilter':0, 'iBG': 1000, 'sTopic': 'topic', 'sQuestion': 'question', 'iGetRisk': 1, 'iGetRisk': 1, 'iGetEDP': 1})
if os.path.isfile("6.wav"):
	if showedRT==False:
		showedRT=True
		print("\n\nREALTIME ANALYSIS:")
	print ("\nAnalyze 6.wav - the results are stored in 6.csv")
	wav2pcm("6.wav", "6.pcm")
	realtimeAnalysis("6.csv", "6.pcm", {'iChannels': 2, 'iSegMaxLen':2, 'iNoiseFilter':0, 'iBG': 1000, 'sTopic': 'topic', 'sQuestion': 'question', 'iGetRisk': 1, 'iGetEDP': 1})

print("")
