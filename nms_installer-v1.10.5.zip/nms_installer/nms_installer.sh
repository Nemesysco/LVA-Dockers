#!/bin/bash

nbVar=$#
xampp=0
url=""
path=""
app=""
docker=0
distr=""
ver=""
systemd=0
type="full"
useSite=1


# Xampp Variables
xampp_url="https://www.apachefriends.org/index.html"
xampp_path="/opt/lampp"
xampp_serviceSystemd=`cat <<EOF
[Unit]
Description=XAMPP

[Service]
ExecStart=/opt/lampp/lampp start
ExecStop=/opt/lampp/lampp stop
Type=forking

[Install]
WantedBy=multi-user.target
EOF`

xampp_serviceInitd=`cat <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides: lampp
# Required-Start:    $local_fs $syslog $remote_fs dbus
# Required-Stop:     $local_fs $syslog $remote_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start lampp
### END INIT INFO
/opt/lampp/lampp start
EOF`

function help {
	echo
	echo -e "$0 app="application" [xampp] [docker] [url="url of the server" path="path to the root of the web server"] [help]"
	echo -e "\t app=  application to install:"
	echo -e "\t\t app=LVA7 : install LVA7"
	echo -e "\t\t app=QA7 : install QA7"
	echo -e "\t docker : install docker if docker is not already installed. If docker is installed, it will do nothing"
	echo -e "\t xampp : install XAMPP web server"
	echo -e "\t\t don't use path= and url= with xampp"
	echo -e "\t path=web_server_root_path : path must be set to the path to the sub-directory where your"
	echo -e "\t\t example 1: path=/var/www/html/"
	echo -e "\t\t example 2: path=/opt/lampp/htdocs/"
	echo -e "\t url=server_url : url of your server"
	echo -e "\t\t example 1: url=http://127.0.0.1/"
	echo -e "\t\t example 2: url=https://my_server.com/"
	echo -e "\t help : show this help"
	echo
	echo -e "Examples:"
	echo -e "\t $0 app=QA7 xampp docker : install both docker and xampp (as webserver) before install the QA7 site and QA7 docker instance"
	echo -e "\t $0 app=LVA7 path=/var/html/www url=http://127.0.0.1 : install LVA7 site"
	echo
	echo -e "Notes:"
	echo -e "\t - Both 'xampp' and 'docker' options requires that the distribution uses systemd (most major distributions)"
	echo -e "\t - The option 'docker' works only for the distributions officially supported by docker:"
	echo -e "\t\t - Ubuntu: 18.04, 20.04, 20.10 and 21.04"
	echo -e "\t\t - Debian: 10 and 11"
	echo -e "\t\t - Centos: 7 and 8"
	#echo -e "\t\t - Fedora: 30 and 31"
	exit
}


function strFind() {
	str=$1
	lookFor=$2
	
	rc=`echo "$str"|grep "$lookFor"`
	echo "$rc"
}

function confirm() {
	if [[ $# != 1 ]]; then
		question="Are you sure? [Y/n] "
	else
		question="$1 [Y/n] "
	fi

	while true
	do
		read -r -p "$question" input
		case $input in 
			[yY][eE][sS]|[yY]):
				return 1
				break
				;;
			[nN][oO]|[nN]):
				return 0
				break
				;;
			*)
				echo "Invalid Input..."
				;;
		esac
	done
}

function isRoot()
{
	if [ "$EUID" -ne 0 ]; then
		return 0
	else
		return 1
	fi
}

function xampp_install {
	echo Download XAMPP
	echo ==============
	echo $xampp_url
	xamppIndex=`wget -qO- "$xampp_url" 2>/dev/zero`
	while IFS=" " read -r line
	found=false
	do
		line2=`echo $line|grep 'href="https://www.apachefriends.org/xampp-files/'`
		line3=`echo $line2 |grep 'xampp-linux-x64'`
		if [ "$line3" != "" ]; then
			IFS='"'
			read -a rline <<< "$line3"
			for val in "${rline[@]}"; do
				xampPATH=`echo $val |grep 'xampp-linux-x64'`
				if [ "$xampPATH" != "" ]; then
					found=true
					break
				fi
			done
			
			if [ $found == true ]; then
				break
			fi
		fi
	done < <(printf '%s\n' "$xamppIndex")

	wget -O xampp.bin $xampPATH 
	chmod +x xampp.bin

	echo Install XAMPP
	echo =============
	sudo ./xampp.bin --mode unattended --unattendedmodeui minimal
	rm -f /xampp.bin

	# Start xampp on boot
	echo Install XAMPP Service
	echo =====================
	serviceFile="/etc/systemd/system/xampp.service"
	sudo cp xampp_serviceSystemd $serviceFile
	sudo systemctl enable xampp.service

	echo Start XAMPP
	echo ===========
	sudo /opt/lampp/lampp start
}

function docker_postinstall {
	tmp=`cat /etc/group|grep 'docker:'`
	tmp2=`echo $tmp| grep $USER`
	if [ -z "$tmp" ]; then
		sudo groupadd docker
		sudo usermod -aG docker $USER
	elif [ -z "$tmp2" ]; then
		sudo usermod -aG docker $USER
	fi	
	sudo systemctl enable docker
}


function docker_ubuntu {	
	sudo apt-get update
	sudo apt-get install -y \
		apt-transport-https \
		ca-certificates \
		curl \
		gnupg \
		lsb-release	
	curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

	 echo \
	  "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
	  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
	  
	sudo apt-get update
	sudo apt-get install -y docker-ce docker-ce-cli containerd.io
		
	docker_postinstall
}

function docker_static {
	# Install docker
	
	# Install Docker
	dockList=`wget -qO- https://download.docker.com/linux/static/stable/x86_64/|grep tgz|cut -d'"' -f2|grep -v extras`
	dockFile=dockFile=${dockList##*$'\n'}
	wget https://download.docker.com/linux/static/stable/x86_64/$dockFile
	tar xzvf $dockFile
	sudo cp docker/* /usr/bin/
	sudo docker &
}

function docker_debian {
	sudo apt-get update
	sudo apt-get install -y
		apt-transport-https \
		ca-certificates \
		curl \
		gnupg \
		lsb-release
	curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

	echo \
	  "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/debian \
	  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
	  
	sudo apt-get update
	sudo apt-get install -y docker-ce docker-ce-cli containerd.io

	docker_postinstall
}

function docker_centos {
	sudo yum install -y yum-utils
	sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
	sudo yum install -y docker-ce docker-ce-cli containerd.io
	
	sudo systemctl start docker
	docker_postinstall
}

function docker_fedora {
	sudo dnf -y install dnf-plugins-core
	sudo dnf config-manager -y --add-repo https://download.docker.com/linux/fedora/docker-ce.repos
	sudo dnf -y install docker-ce docker-ce-cli containerd.io	
	
	sudo systemctl start docker
	docker_postinstall	
}

#----------------------------------------------------------------------------------------------------

rmDocker=0
for i in $*
do
	left=`echo $i | cut -d'=' -f 1`
	right=`echo $i | cut -d'=' -f 2`

	left=${left,,}
	case "$left" in
		"xampp" ) xampp=1 ;;
		#"--docker-no-install" )
		#	if [ -z "`which docker`" ]; then
		#		echo Docker is not installed
		#		exit 0
		#	fi
		#	;;
		#"--reinstall-docker" )
		#	if [ -e "`which docker`" ]; then rmDocker=1; fi ;;
		"docker" ) docker=1 ;;
		"app" ) app=$right ;;
		"url" ) url=$right ;;
		"path" ) path=$right ;;
		"type" ) type=$right ;;
		"ipServer" ) host="-e IPSRC=set -e IP=$right" ;;
		"help" ) help ;;
		* ) echo help ;;
	esac
done

case "$app" in
	"LVA7" )
		portServer=12000
		portRealtime=12001
		app="LVA7"
		dockerImage="nemesysco/lva7service"
		;;
	"QA7" )
		portServer=12100
		portRealtime=12101
		app="QA7"
		dockerImage="nemesysco/qa7service"
		;;
	* ) echo "Error: Unknown app '$app'"; echo; help ;;
esac

case "$type" in
	"full" ) docker_type="-p $portRealtime:$portRealtime/tcp" ;;
	"server" ) docker_type="-p $portServer:$portServer/tcp -e startServer=1 -e startOffline=0 -e startOnline=0" ;;
	"offline" ) docker_type="-e startServer=1 -e startOffline=0 -e startOnline=0 $host" ;;
	"realtime" ) docker_type="-p $portRealtime:$portRealtime/tcp -e startServer=0 -e startOffline=0 -e startOnline=1 $host" 
		useSite=0 ;;
	* ) echo "Error: Type '$type' unknown"; echo; help ;;
esac

if [ $xampp == 1 ]; then
	if [ "$path" == "" ] && [ "$url" == "" ]; then
		path="/opt/lampp/htdocs/"
		url="http://127.0.0.1/"
	else
		echo "Error: 'xampp' must not be used with 'url' or 'path'"
		echo
		help
		exit
	fi
else
	if [ "$path" == "" ] || [ "$url" == "" ]; then
		echo "Error: When XAMPP is not install, you need to define both 'url' and 'path'"
		echo
		help
		exit
	fi
fi


tmp=`which hostnamectl`
if [ "$tmp" != "" ]; then
	set=0
	systemd=1
	sys=`hostnamectl|grep "Operating System"`
	
	if [ $set == 0 ] && [[ `strFind "$sys" "Ubuntu"` ]]; then
		distr="Ubuntu"
		set=1
		if [[ `strFind "$sys" "18.04"` ]]; then
			ver="18.04"
		elif [[ `strFind "$sys" "20.04"` ]]; then
			ver="20.04"
		elif [[ `strFind "$sys" "20.10"` ]]; then
			ver="20.10"
		elif [[ `strFind "$sys" "21.04"` ]]; then
			ver="21.04"
		else
			set=2
			ver="21.04"
		fi
	elif [ $set == 0 ] && [[ `strFind "$sys" "CentOS"` ]]; then
		distr="Centos"
		set=1
		if [[ `strFind "$sys" "Linux 7"` ]]; then
			ver="7"
		else
			ver="8"
			set=2
		fi
	elif [ $set == 0 ] && [[ `strFind "$sys" "Debian"` ]]; then
		distr="Debian"
		set=1
		if [[ `strFind "$sys" "GNU/Linux 10"` ]]; then
			ver="10"
		elif [[ `strFind "$sys" "GNU/Linux 11"` ]]; then
			ver="11"
		else
			ver="10"
			set=2
		fi
	elif [ $set == 500 ] && [[ `strFind "$sys" "Fedora"` ]]; then
		distr="Fedora"
		set=1
		if [[ `strFind "$sys" "Fedora 32"` ]]; then
			ver="32"
		elif [[ `strFind "$sys" "Fedora 33"` ]]; then
			ver="33"
		elif [[ `strFind "$sys" "Fedora 34"` ]]; then
			ver="34"
		else
			ver="34"
			set=2
		fi
	else
		set=3
	fi
fi


if [ $xampp == 1 ]; then
	if [ -d "/opt/lampp" ]; then
		echo "Error: XAMPP seems to already be installed. The directory /opt/lampp exists"
		echo
		help
		exit
	fi
fi

if [ -n "`which docker`" ]; then
	docker=0
elif [ $set == 2 ]; then
	confirm "The version of $distr is unknown, should I try to install docker anyway?"
	case $? in
		1 ) set=1;; 
		0 ) echo "Install Docker manually and relaunch the installer"; exit 0;;
	esac
elif [ $set == 3 ]; then
	echo "Unknown Linux Version - Install Docker Manually and relaunch the installer"
	exit 0
fi

if [ $docker == 1 ]; then
	case "$distr" in
		"Ubuntu" ) docker_ubuntu ;;
		"Debian" ) docker_debian ;;
		"Centos" ) docker_centos ;;
		"Fedora" ) docker_fedora ;;
		* )
			echo -e "Error: Unknown distribution"
			echo -e "\t Install docker manually"
			echo
			help
			exit
			;;
	esac
fi

test=`which docker`
if [ "$test" == "" ]; then
	echo -e "Error: Docker is not present"
	echo -e "\t Add the 'docker' argument to install docker automatically"
	echo -e "\t Or install docker manually"
	echo
	help
	exit
fi

if [ $xampp == 1 ]; then
	xampp_install
	if [ "$distr" == "Centos" ] && [ "$ver" == "7" ]; then
		sudo sed -i 's/export LD_ASSUME_KERNEL=2.2.5/do_nothing=1 #export LD_ASSUME_KERNEL=2.2.5/' /opt/lampp/lampp
		sudo /opt/lampp/lampp start
	fi

fi

# Install site
sudo mkdir -p "$path/$app"
sudo tar -C "$path/$app" -xvf nms_docker_site.tgz
sudo chmod 0777 "$path/$app/dir" "$path/$app/records" "$path/$app/json" "$path/$app/share"
sudo echo -n 1 > "$path/$app/dir/counter"
sudo chmod 0666  "$path/$app/dir/counter"
sudo sed -i 's#%app%#'$app'#g' "$path/$app/_config.php"
sudo sed -i 's#%url%#'$url'#g' "$path/$app/_config.php"
sudo sed -i 's#%path%#'$path'#g' "$path/$app/_config.php"

# Start docker
script="$app"_reset.sh
cmd="sudo docker run --restart=unless-stopped -d -v $path/$app/share:/share -v $path/$app/records:/records $docker_type -e LOG=0  --name $app $dockerImage"
echo "#!/bin/bash" > $script
echo $cmd >> $script
echo "sudo docker kill $app" >> $script
echo "sudo docker rm $app" >> $script
echo  >> $script
chmod +x $script
eval "$cmd"
